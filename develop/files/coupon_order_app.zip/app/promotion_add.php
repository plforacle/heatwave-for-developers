<?php

 // Include config file
require_once "config.php";

// Attempt insert query execution
$sql = "INSERT INTO  coupon_tracking(promotion_id,coupon_id,customer_id,redemption_status)
            select 100 ,coupon_id,1,0 
            from coupon
            where coupon_id > 37
            order by coupon_id;";

if(!mysqli_query($link, $sql)){
    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
    header("location: error.php");
    // Close connection
    mysqli_close($link);
    exit();
}



$sql = "SELECT title FROM mysql_customer_orders.coupon where coupon_id  >37;";

 $result = mysqli_query($link,  $sql);  
 // Close connection
 mysqli_close($link);
 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
      body{ font: 14px sans-serif; text-align: center;
                background-image: url('images/eureka_background.png');
                background-repeat:no-repeat;
                background-size:cover;
                padding: 30px;
        }
        img {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

    </style>
</head>
<body>
    <img src="images/Eurekalogo204Artboard4.png" class="center" height="150"    
                alt="MDB Logo" loading="lazy" />
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
            <div class="col-sm" >
            <div class="align-self-end">
                        <br>  
                        <a href="promotion_shop.php" class="btn btn-success">Shop</a>
                        <a href="promotion_thank_you.php" class="btn btn-danger">Exit</a>
                    </div>
                    <div class="page-header">
                        <h2>Eureka Promotion Coupons</h2>
                    </div>
                    <h4>Hello PLF,<br>
                       Thank you for accepting our coupon discount recomendation.
                       Your coupons will automatically be redeemed 
                       ,for each corresponding purchase items,
                       when you shop with us.
                       You are now ready to go shopping and save money. 
                       Please hit the Shop button to continue.
                       <br>
                    </h4>
                    <div class="table-responsive">  
                    <table id="employee_data" class="table table-bordered">  
                          <thead>  
                               <tr>  
                                    <td><b>CouponName</b></td>  
                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["title"].'</td>  
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table> 
                     
                     </div>
                </div> 
                </div> 

            </div>        
        </div>
    </div>
</body>
</html>
