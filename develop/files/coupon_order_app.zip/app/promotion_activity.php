<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
      body{ font: 14px sans-serif; text-align: center;
                background-image: url('images/eureka_background.png');
                background-repeat:no-repeat;
                background-size:cover;
                padding: 30px;
        }

        img {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
    <img src="images/Eurekalogo204Artboard4.png" class="center" height="150"    
                alt="Eureka Logo" loading="lazy" />
    <div class="wrapper">
        <div class="w3-container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h1 class="pull-left">Items purchased by plf from  2022-01-01 to 2022-12-31</h1>
                        <a href="promotion_details.php?id=13" class="btn btn-success pull-right">Loyalty Reward Promotions</a>
                    </div>
                    <?php
                    // Include config file
                    require_once "config.php";
                    
                    // Attempt select query execution
                    $sql = "select customer_id,order_datetime purchase_date
                    ,unit_price,discount,quantity,order_amount_total,order_discount_total
                    ,ROUND((order_amount_total - order_discount_total),1) purchase_total
                    ,start_date,end_date,coupon_redemption_status,product_name product_title
                    FROM customer_order_product_coupon_view 
					where customer_id=1 and promotion_id =99
                    order by order_datetime;";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo "<table class='table table-bordered'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>#</th>";
                                        echo "<th>purchase_date</th>";
                                        echo "<th>product_name</th>";
                                        echo "<th>quantity</th>";
                                        echo "<th>unit_price</th>";
                                        echo "<th>unit_discount</th>";
                                        echo "<th>order_amount_total</th>";
                                        echo "<th>order_discount_total</th>";
                                        echo "<th>purchase_total</th>";
                                        echo "<th>coupon_start_date</th>";
                                        echo "<th>coupon_end_date</th>";
                                        echo "<th>coupon_redemption_status</th>";
					            echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                $index = 1;
                                while($row = mysqli_fetch_array($result)){
                                        echo "<tr>";
                                        echo "<td>$index</td>";
                                        echo "<td>" . $row['purchase_date'] . "</td>";
                                        echo "<td>" . $row['product_title'] . "</td>";
                                        echo "<td>" . $row['quantity'] . "</td>";
                                        echo "<td>" . $row['unit_price'] . "</td>";
                                        echo "<td>" . $row['discount'] . "</td>";
                                        echo "<td>" . $row['order_amount_total'] . "</td>";
                                        echo "<td>" . $row['order_discount_total'] . "</td>";
                                        echo "<td>" . $row['purchase_total'] . "</td>";
                                        echo "<td>" . $row['start_date'] . "</td>";
                                        echo "<td>" . $row['end_date'] . "</td>";
                                        echo "<td>" . $row['coupon_redemption_status'] . "</td>";
                                        $index = $index +1;
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                    }
 
                    // Close connection
                    mysqli_close($link);
                    ?>
                    
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
