<?php
// Initialize the session
session_start();
 
// Unset all of the session variables
$_SESSION = array();
require_once "config.php";
$result = mysqli_query($link, "CALL reset_purchase");
// Destroy the session.
session_destroy();
 
// Redirect to login page
header("location: login.php");
exit;
?>
