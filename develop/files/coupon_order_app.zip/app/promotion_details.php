<?php  
// Include config file
require_once "config.php";

$sql = "select title, discount coupon_amount_saved from coupon where coupon_id >37;";

 $result = mysqli_query($link,  $sql);  
 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
      body{ font: 14px sans-serif; text-align: center;
                background-image: url('images/eureka_background.png');
                background-repeat:no-repeat;
                background-size:cover;
                padding: 30px;
        }
        img {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

    </style>
</head>
<body>
    <img src="images/Eurekalogo204Artboard4.png" class="center" height="150"    
                alt="MDB Logo" loading="lazy" />
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
            <div class="col-sm" >
            <div class="align-self-end">
                        <br>  
                        <a href="promotion_add.php" class="btn btn-success">Accept</a>
                        <a href="promotion_thank_you.php" class="btn btn-danger">Exit</a>
                    </div> 
                    <div class="page-header">
                        <h2>Eureka Promotions</h2>
                        <h4>Hello PLF,<br>
                       Thank you for shopping with us. 
                       As a token of our appreciation, we are offering you 
                       the following discount coupons.
                       The coupon saving tells how much you can save 
                       on your next purchase just by selecting the Accept button below. 
                       <br>
                        </h4>
                    </div>
         
                     <table id="employee_data" class="table table-bordered">  
                          <thead>  
                               <tr>  
                                    <th>CouponName</th>  
                                    <th>Potential coupon saving</th>  
                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["title"].'</td>  
                                    <td>'.$row["coupon_amount_saved"].'</td>  
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table> 
                     </div>
                </div> 
                </div> 

            </div>        
        </div>
    </div>
</body>
</html>
