<?php
/* Database credentials. Assuming you are running MySQL */
#define('DB_SERVER', '10.0.1.59');
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'admin');
define('DB_PASSWORD', 'Welcome#123');
define('DB_NAME', 'mysql_customer_orders');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Print host information
//echo "Connect Successfully. Host info: " . mysqli_get_host_info($link);
/*
$result = mysqli_query($link, "set use_secondary_engine=Off;");

if ($result = mysqli_query($link, "select use_secondary_engine;")) {
    $row = mysqli_fetch_row($result);
    #printf("use_secondary_engine is %s\n", $row[0]);
    mysqli_free_result($result);
}*/

?>
