<?php
session_start();

// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit();
}
//$con = mysqli_connect('localhost','admin','Welcome#123','mysql_customer_orders');
require_once "config.php";
$result = mysqli_query($link, "CALL reset_purchase");
?>
<!DOCTYPE HTML>
<html>
<head>
 <meta charset="utf-8">
 <title>TechJunkGigs</title>
 <script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script type="text/javascript">
 google.load("visualization", "1", {packages:["corechart"]});
 google.setOnLoadCallback(drawChart);
 function drawChart() {
 var data = google.visualization.arrayToDataTable([

 ['month','total purchases'],
 <?php
 $query = " select monthname(order_datetime) month, sum(order_amount_total) order_total
            from customer_order_product_coupon_view
            where customer_id = 1 and campaign_id=1
            group by month
            order by  month, order_total; ";

 $exec = mysqli_query($link, $query);
 while ($row = mysqli_fetch_array($exec)) {
     echo "['" . $row["month"] . "'," . $row["order_total"] . "],";
 }
 ?> 
 
 ]);

 var options = {
 title: 'Number of redeemed  coupons',
  pieHole: 0.5,
          pieSliceTextStyle: {
            color: 'black',
          },
          legend: '1'
 };
 var chart = new google.visualization.PieChart(document.getElementById("columnchart12"));
 chart.draw(data,options);

 var data2 = google.visualization.arrayToDataTable([

['month','Items Purchased'],
<?php
$sql = " select monthname(order_datetime) month,sum(quantity) as quantity
           from customer_order_product_coupon_view
           where customer_id = 1 and campaign_id=1
           group by month
           order by  month, quantity;";

$exec = mysqli_query($link, $sql);
while ($row = mysqli_fetch_array($exec)) {
    echo "['" . $row["month"] . "'," . $row["quantity"] . "],";
}
?> 

]);

 var options2 = {
 title: 'Total Items purchased for customer #1475',
  pieHole: 0.5,
          pieSliceTextStyle: {
            color: 'black',
          },
          legend: 'none'
 };
 var chart2 = new google.visualization.ColumnChart(document.getElementById("columnchart13"));
 chart2.draw(data2,options2);
 var data3 = google.visualization.arrayToDataTable([

['2020 month','coupons used'],
<?php
$sql = "select monthname(order_datetime) month, 
           case
             when coupon_redemption_status =1 then  sum(abs(discount))
             else 0
           end sum_coupon_discount
           from customer_order_product_coupon_view 
           where customer_id = 1 and campaign_id=1 
           group by month
           order by  month, sum_coupon_discount;";

$exec = mysqli_query($link, $sql);
while ($row = mysqli_fetch_array($exec)) {
    echo "['" . $row["month"] . "'," . $row["sum_coupon_discount"] . "],";
}
?> 

]);
 var options3 = {
 title: 'total amount saved with coupons for custoer #1475',
  pieHole: 0.5,
          pieSliceTextStyle: {
            color: 'black',
          },
          legend: 'none'
 };

 var chart3 = new google.visualization.ScatterChart(document.getElementById("columnchart14"));
 chart3.draw(data3,options3);
} //end  function drawChart()

</script>
<style type="text/css">
    body{ font: 14px sans-serif; text-align: center; }
    
</style>
</head>
<body>
<div class="page-header">
    <h1>Hi, <b><?php echo htmlspecialchars(
        $_SESSION["username"]
    ); ?></b>. Welcome to our site.</h1>
</div>
<p>
        <a href="reset-password.php" class="btn btn-warning">Reset Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out</a>
        <a href="promotion_activity.php" class="btn btn-success">View Account Activity</a>
</p>
<div class="h-100 row align-items-center"> 
  <div class="col-sm-4">
  <div id="columnchart12" style="width: 100%; height: 500px;"></div>
  </div>
  <div class="col-sm-4">
  <div id="columnchart13" style="width: 100%; height: 500px;"></div>
  </div>
  <div class="col-sm-4">
  <div id="columnchart14" style="width: 100%; height: 500px;"></div>
  </div>
</div>

</body>
</html>