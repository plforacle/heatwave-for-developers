<?php
// Include config file

require_once "config.php";

$sql = "SELECT coupon_id, title, discount, product_id, unit_price,product_name, review
, customer_id, redemption_status, start_date, end_date, activedays
FROM mysql_customer_orders.customer_coupon_view 
where  customer_id = 1 and activedays > 0 limit  5;";

 $result = mysqli_query($link,  $sql);  
 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style type="text/css">
      body{ font: 14px sans-serif; text-align: center;
                background-image: url('images/eureka_background.png');
                background-repeat:no-repeat;
                background-size:cover;
                padding: 30px;
        }
        img {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

    </style>
</head>
<body>
<img src="images/Eurekalogo204Artboard4.png" class="center" height="150"    
                alt="MDB Logo" loading="lazy" />   
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
            <div class="col-sm" >
                    <div class="page-header">
                        <h2>Eureka Promotions</h2>
                    </div>
                    <h4> PLF,<br>
                       Thank you for deciding to Shop with us today. 
                       Please select the product(s) you wish to purchase and hit Submit
                       <br>
                       <br>
                    </h4>
                    <div><?php if(isset($message)) { echo $message; } ?>
                    </div>
                    <form method="post" action="promotion_shop_add.php">
                    <table class="table table-bordered">  
                    <thead>  
                    <tr> 
                        <th><input type="checkbox" id="checkAl"> Select All</th> 
                            <th>product_id</th>  
                            <th>product_name</th>
                            <th>unit_price</th>   
                            <th>discount</th>
                            <th>review</th>  
                    </tr>  
                    </thead>  
                    <?php 
                    $i=0; 
                    while($row = mysqli_fetch_array($result))  {  
                    ?>
                    <tr>  
                        <td><input type="checkbox" id="checkItem" name="check[]" value="<?php 
                        echo $row["product_id"];
                        echo ",";
                        echo $row["unit_price"];
                        ?>"></td>
                            <td><?php echo $row["product_id"]; ?></td>  
                            <td><?php echo $row["product_name"]; ?></td>
                            <td><?php echo $row["unit_price"]; ?></td>  
                            <td><?php echo $row["discount"]; ?></td>  
                            <td><?php echo $row["review"]; ?></td>
 
                    </tr>  
                    <?php
                    $i++;
                    }  
                    ?>  
                    </table>
                    <p align="center"><button type="submit" class="btn btn-success" name="save">Submit</button></p>
                    <p align="center"><a class="btn btn-danger" href="promotion_thank_you.php" role="button">Exit</a></p>
                    </form>
                    <script>
                        $("#checkAl").click(function () {
                        $('input:checkbox').not(this).prop('checked', this.checked);
                        });
                    </script>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>